# Discord VPS Maker Bot

A comprehensive Discord bot for managing VPS instances using tmate sessions and Docker containers.

## Features

### Admin Features
- Deploy VPS for specific users with custom specifications
- List all active VPS instances
- Delete VPS instances by VM ID
- Full administrative control over all instances

### User Features
- View their own VPS instances
- Manage VPS with interactive buttons (restart, stop, view specs, delete)
- Receive VPS details via DM when deployed

### Technical Features
- Tmate session integration for SSH access
- Docker container management
- Persistent data storage in JSON
- Support for multiple operating systems
- Secure password generation
- Interactive Discord slash commands

## Prerequisites

1. **Node.js** (v16 or higher)
2. **Docker** installed and running
3. **tmate** installed (`sudo apt install tmate` on Ubuntu/Debian)
4. **Discord Bot Token** from Discord Developer Portal

## Installation

1. Clone or download the bot files
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Set up your environment:
   \`\`\`bash
   export DISCORD_BOT_TOKEN="your_bot_token_here"
   \`\`\`

4. Update the configuration in `bot.js`:
   \`\`\`javascript
   ADMIN_IDS: [
       'your_discord_user_id_here',
       'another_admin_id_here'
   ]
   \`\`\`

5. Start the bot:
   \`\`\`bash
   npm start
   \`\`\`

## Commands

### Admin Commands
- `/deploy @user [RAM] [CPU] [STORAGE] [OS] [PASSWORD]` - Deploy VPS for a user
- `/list` - List all active VPS instances
- `/delete [vm_id]` - Delete a VPS by VM ID

### User Commands
- `/myvps` - List your VPS instances
- `/manage [vm_id]` - Interactive VPS management panel

## Supported Operating Systems
- Ubuntu
- Debian
- CentOS
- Kali Linux
- Alpine
- Fedora

## Configuration

### Resource Limits
- **RAM**: 512MB - 8192MB
- **CPU**: 1 - 4 cores
- **Storage**: 5GB - 50GB

### Admin Setup
Add your Discord user IDs to the `ADMIN_IDS` array in the configuration section.

## Security Features
- Admin-only deployment commands
- User ownership verification
- Secure password generation
- Isolated Docker containers
- Tmate session management

## Data Persistence
VPS data is automatically saved to `vps_data.json` and restored on bot restart.

## Troubleshooting

1. **Bot not responding**: Check if the bot token is correct and the bot is online
2. **Docker errors**: Ensure Docker is running and you have proper permissions
3. **Tmate issues**: Verify tmate is installed and accessible
4. **Permission errors**: Make sure admin user IDs are correctly configured

## Support
For issues or questions, check the bot logs for detailed error messages.
