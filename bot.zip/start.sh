#!/bin/bash

# Discord VPS Bot Startup Script

echo "🚀 Starting Discord VPS Maker Bot Setup..."

# Function to detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            echo "debian"
        elif [ -f /etc/redhat-release ]; then
            echo "redhat"
        else
            echo "linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "macos"
    else
        echo "unknown"
    fi
}

# Install Node.js
install_nodejs() {
    echo "📦 Installing Node.js..."
    OS=$(detect_os)
    
    case $OS in
        "debian")
            curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
            sudo apt-get install -y nodejs
            ;;
        "redhat")
            curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
            sudo yum install -y nodejs npm
            ;;
        "macos")
            if command -v brew &> /dev/null; then
                brew install node
            else
                echo "❌ Homebrew not found. Please install Node.js manually from https://nodejs.org"
                exit 1
            fi
            ;;
        *)
            echo "❌ Unsupported OS. Please install Node.js manually from https://nodejs.org"
            exit 1
            ;;
    esac
}

# Install Docker
install_docker() {
    echo "🐳 Installing Docker..."
    OS=$(detect_os)
    
    case $OS in
        "debian")
            sudo apt-get update
            sudo apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release
            curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
            sudo apt-get update
            sudo apt-get install -y docker-ce docker-ce-cli containerd.io
            sudo usermod -aG docker $USER
            ;;
        "redhat")
            sudo yum install -y yum-utils
            sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
            sudo yum install -y docker-ce docker-ce-cli containerd.io
            sudo systemctl start docker
            sudo systemctl enable docker
            sudo usermod -aG docker $USER
            ;;
        "macos")
            echo "❌ Please install Docker Desktop for Mac manually from https://docker.com"
            exit 1
            ;;
        *)
            echo "❌ Unsupported OS. Please install Docker manually from https://docker.com"
            exit 1
            ;;
    esac
    
    echo "⚠️  You may need to log out and back in for Docker permissions to take effect."
}

if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Installing automatically..."
    install_nodejs
fi

if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Installing automatically..."
    install_docker
fi

# Check if tmate is installed
if ! command -v tmate &> /dev/null; then
    echo "❌ tmate is not installed. Installing tmate..."
    OS=$(detect_os)
    case $OS in
        "debian")
            sudo apt update && sudo apt install -y tmate
            ;;
        "redhat")
            sudo yum install -y epel-release && sudo yum install -y tmate
            ;;
        "macos")
            if command -v brew &> /dev/null; then
                brew install tmate
            else
                echo "❌ Please install tmate manually"
                exit 1
            fi
            ;;
    esac
fi

# Check if dependencies are installed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
fi

if [ -z "$DISCORD_BOT_TOKEN" ]; then
    echo ""
    echo "🔑 Discord Bot Configuration"
    echo "================================"
    read -p "Enter your Discord Bot Token: " BOT_TOKEN
    export DISCORD_BOT_TOKEN="$BOT_TOKEN"
    
    # Save to .env file for persistence
    echo "DISCORD_BOT_TOKEN=$BOT_TOKEN" > .env
fi

if [ -z "$ADMIN_IDS" ]; then
    echo ""
    echo "👑 Admin Configuration"
    echo "======================"
    echo "Enter Discord User IDs of admins (comma-separated):"
    echo "Example: 123456789012345678,987654321098765432"
    read -p "Admin IDs: " ADMIN_INPUT
    export ADMIN_IDS="$ADMIN_INPUT"
    
    # Append to .env file
    echo "ADMIN_IDS=$ADMIN_INPUT" >> .env
    
    echo ""
    echo "✅ Configuration saved to .env file"
fi

# Start the bot
echo ""
echo "✅ All checks passed. Starting Discord VPS Maker Bot..."
echo "🤖 Bot is now running. Press Ctrl+C to stop."
echo ""
node bot.js
