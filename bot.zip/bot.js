const {
  Client,
  GatewayIntentBits,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActivityType, // Added ActivityType import for proper activity setting
} = require("discord.js")
const { spawn, exec } = require("child_process")
const fs = require("fs").promises
const path = require("path")
const crypto = require("crypto")

// Configuration
const CONFIG = {
  // Add your bot token here
  BOT_TOKEN: process.env.DISCORD_BOT_TOKEN || "YOUR_BOT_TOKEN_HERE",

  ADMIN_IDS: process.env.ADMIN_IDS
    ? process.env.ADMIN_IDS.split(",")
        .map((id) => id.trim())
        .filter(Boolean)
    : [],

  // Supported operating systems
  SUPPORTED_OS: {
    ubuntu: "ubuntu:latest",
    debian: "debian:latest",
    centos: "centos:latest",
    kali: "kalilinux/kali-rolling:latest",
    alpine: "alpine:latest",
    fedora: "fedora:latest",
  },

  // Default limits
  MAX_RAM: 8192, // MB
  MAX_CPU: 4,
  MAX_STORAGE: 50, // GB

  // Data file
  DATA_FILE: "./vps_data.json",
}

class VPSManager {
  constructor() {
    this.vpsData = new Map()
    this.tmateProcesses = new Map() // Added proper tracking of tmate processes
    this.loadData()
  }

  async loadData() {
    try {
      const data = await fs.readFile(CONFIG.DATA_FILE, "utf8")
      const parsed = JSON.parse(data)
      this.vpsData = new Map(Object.entries(parsed))
      console.log(`Loaded ${this.vpsData.size} VPS instances from storage`)
    } catch (error) {
      if (error.code === "ENOENT") {
        console.log("No existing data file found, starting fresh")
      } else {
        console.error("Error loading data:", error.message) // Better error handling
      }
      this.vpsData = new Map()
    }
  }

  async saveData() {
    try {
      const dataObj = Object.fromEntries(this.vpsData)
      await fs.writeFile(CONFIG.DATA_FILE, JSON.stringify(dataObj, null, 2))
    } catch (error) {
      console.error("Error saving data:", error.message) // Improved error logging
      throw error // Re-throw to handle upstream
    }
  }

  generateVMID() {
    return "vm_" + crypto.randomBytes(4).toString("hex")
  }

  generatePassword() {
    return crypto.randomBytes(8).toString("hex")
  }

  async createTmateSession(vmId) {
    return new Promise((resolve, reject) => {
      const sessionPath = `/tmp/${vmId}`

      // First, create a new tmate session
      const tmateProcess = spawn("tmate", [
        "-S",
        sessionPath,
        "new-session",
        "-d", // Run in detached mode
      ])

      tmateProcess.on("error", (error) => {
        reject(new Error(`Failed to start tmate: ${error.message}`))
      })

      this.tmateProcesses.set(vmId, tmateProcess)

      // Wait for tmate session to be ready
      setTimeout(() => {
        // Wait for tmate to be ready
        exec(`tmate -S ${sessionPath} wait tmate-ready`, (waitError) => {
          if (waitError) {
            reject(new Error(`Tmate session not ready: ${waitError.message}`))
            return
          }

          // Now get the SSH connection info
          exec(`tmate -S ${sessionPath} display -p '#{tmate_ssh}'`, (error, stdout) => {
            if (error) {
              reject(new Error(`Failed to get SSH info: ${error.message}`))
              return
            }

            const sshCommand = stdout.trim()
            if (!sshCommand) {
              reject(new Error("No SSH command received from tmate"))
              return
            }

            resolve({
              process: tmateProcess,
              sshCommand: sshCommand,
              sessionFile: sessionPath,
            })
          })
        })
      }, 5000) // Increased wait time for better reliability
    })
  }

  async createVPS(specs) {
    const vmId = this.generateVMID()
    const password = specs.password || this.generatePassword()

    try {
      // Create tmate session
      const tmateSession = await this.createTmateSession(vmId)

      // Create Docker container with specified OS
      const dockerImage = CONFIG.SUPPORTED_OS[specs.os.toLowerCase()]
      if (!dockerImage) {
        throw new Error(`Unsupported OS: ${specs.os}`)
      }

      const dockerCommand = [
        "docker",
        "run",
        "-d",
        "--name",
        vmId,
        "--hostname",
        `srjhosting-${vmId}`, // Set custom hostname
        "--privileged", // Required for systemd
        "--memory",
        `${specs.ram}m`,
        "--cpus",
        specs.cpu.toString(),
        "--tmpfs",
        `/tmp`, // Fixed tmpfs syntax - removed invalid size parameter
        "--tmpfs",
        "/run", // Required for systemd
        "--tmpfs",
        "/run/lock", // Required for systemd
        "-v",
        "/sys/fs/cgroup:/sys/fs/cgroup:ro", // Required for systemd
        "-e",
        `ROOT_PASSWORD=${password}`,
        dockerImage,
        "/sbin/init", // Use systemd as init system instead of sleep infinity
      ]

      const dockerProcess = spawn(dockerCommand[0], dockerCommand.slice(1))

      await new Promise((resolve, reject) => {
        let stderr = ""
        dockerProcess.stderr.on("data", (data) => {
          stderr += data.toString()
        })

        dockerProcess.on("close", (code) => {
          if (code === 0) {
            resolve()
          } else {
            reject(new Error(`Docker container creation failed with code ${code}: ${stderr}`)) // Better error reporting
          }
        })
      })

      await new Promise((resolve) => setTimeout(resolve, 8000))

      await this.verifyContainerRunning(vmId)

      // Setup SSH in container
      await this.setupSSHInContainer(vmId, password)

      const vpsInfo = {
        id: vmId,
        owner: specs.owner,
        specs: {
          ram: specs.ram,
          cpu: specs.cpu,
          storage: specs.storage,
          os: specs.os,
        },
        password: password,
        ssh: {
          command: tmateSession.sshCommand,
          sessionFile: tmateSession.sessionFile,
        },
        status: "running",
        createdAt: new Date().toISOString(),
      }

      this.vpsData.set(vmId, vpsInfo)
      await this.saveData()

      return vpsInfo
    } catch (error) {
      console.error(`Error creating VPS ${vmId}:`, error)
      await this.cleanupFailedVPS(vmId)
      throw error
    }
  }

  async verifyContainerRunning(vmId) {
    return new Promise((resolve, reject) => {
      exec(`docker inspect ${vmId} --format='{{.State.Running}}'`, (error, stdout) => {
        if (error) {
          reject(new Error(`Failed to verify container status: ${error.message}`))
          return
        }

        if (stdout.trim() !== "true") {
          reject(new Error(`Container ${vmId} is not running`))
          return
        }

        resolve()
      })
    })
  }

  async cleanupFailedVPS(vmId) {
    try {
      // Kill tmate process if exists
      const tmateProcess = this.tmateProcesses.get(vmId)
      if (tmateProcess) {
        tmateProcess.kill("SIGTERM")
        this.tmateProcesses.delete(vmId)
      }

      // Remove session file
      try {
        await fs.unlink(`/tmp/${vmId}`)
      } catch (e) {
        // File might not exist
      }

      // Remove docker container if exists
      exec(`docker stop ${vmId} 2>/dev/null && docker rm ${vmId} 2>/dev/null`, () => {
        // Ignore errors - container might not exist
      })
    } catch (error) {
      console.error(`Error during cleanup of ${vmId}:`, error.message)
    }
  }

  async setupSSHInContainer(vmId, password) {
    const commands = [
      "apt-get update || yum update -y || apk update", // Support multiple package managers
      "apt-get install -y openssh-server || yum install -y openssh-server || apk add openssh", // Install SSH server
      `echo "root:${password}" | chpasswd`, // Set root password
      'sed -i "s/#PermitRootLogin prohibit-password/PermitRootLogin yes/" /etc/ssh/sshd_config || sed -i "s/#PermitRootLogin yes/PermitRootLogin yes/" /etc/ssh/sshd_config', // Enable root login
      'sed -i "s/#PasswordAuthentication yes/PasswordAuthentication yes/" /etc/ssh/sshd_config', // Enable password auth
      "mkdir -p /var/run/sshd", // Create SSH directory
      "systemctl enable ssh || systemctl enable sshd || true", // Added || true to prevent failures
      "systemctl start ssh || systemctl start sshd || true", // Added || true to prevent failures
    ]

    for (const cmd of commands) {
      try {
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(() => {
            reject(new Error("Command timeout"))
          }, 30000)

          exec(`docker exec ${vmId} bash -c "${cmd}"`, (error, stdout, stderr) => {
            clearTimeout(timeout)
            if (error) {
              console.log(`Command failed (continuing): ${cmd}`)
              console.log(`Error: ${error.message}`)
            }
            resolve() // Continue even if some commands fail
          })
        })
      } catch (error) {
        console.log(`Setup command failed (continuing): ${cmd}`)
      }
    }
  }

  async deleteVPS(vmId) {
    const vps = this.vpsData.get(vmId)
    if (!vps) return false

    try {
      // Kill tmate session
      const tmateProcess = this.tmateProcesses.get(vmId)
      if (tmateProcess) {
        tmateProcess.kill("SIGTERM") // Use SIGTERM for graceful shutdown
        this.tmateProcesses.delete(vmId)
      }

      // Remove session file
      try {
        await fs.unlink(vps.ssh.sessionFile)
      } catch (e) {
        // Session file might not exist
      }

      // Stop and remove Docker container
      await new Promise((resolve) => {
        exec(`docker stop ${vmId} && docker rm ${vmId}`, (error) => {
          if (error) console.error(`Error removing container ${vmId}:`, error.message)
          resolve() // Always resolve to continue cleanup
        })
      })

      this.vpsData.delete(vmId)
      await this.saveData()
      return true
    } catch (error) {
      console.error(`Error deleting VPS ${vmId}:`, error.message)
      return false
    }
  }

  async restartVPS(vmId) {
    const vps = this.vpsData.get(vmId)
    if (!vps) return false

    try {
      await new Promise((resolve, reject) => {
        exec(`docker restart ${vmId}`, (error) => {
          if (error) reject(error)
          else resolve()
        })
      })

      vps.status = "running"
      await this.saveData()
      return true
    } catch (error) {
      console.error(`Error restarting VPS ${vmId}:`, error.message)
      return false
    }
  }

  async stopVPS(vmId) {
    const vps = this.vpsData.get(vmId)
    if (!vps) return false

    try {
      await new Promise((resolve, reject) => {
        exec(`docker stop ${vmId}`, (error) => {
          if (error) reject(error)
          else resolve()
        })
      })

      vps.status = "stopped"
      await this.saveData()
      return true
    } catch (error) {
      console.error(`Error stopping VPS ${vmId}:`, error.message)
      return false
    }
  }

  async cleanup() {
    console.log("Cleaning up tmate processes...")
    for (const [vmId, process] of this.tmateProcesses) {
      try {
        process.kill("SIGTERM")
        console.log(`Killed tmate process for ${vmId}`)
      } catch (error) {
        console.error(`Error killing tmate process for ${vmId}:`, error.message)
      }
    }
    this.tmateProcesses.clear()
  }

  getVPSByOwner(userId) {
    return Array.from(this.vpsData.values()).filter((vps) => vps.owner === userId)
  }

  getAllVPS() {
    return Array.from(this.vpsData.values())
  }

  getVPS(vmId) {
    return this.vpsData.get(vmId)
  }
}

class DiscordVPSBot {
  constructor() {
    this.client = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.DirectMessages],
    })

    this.vpsManager = new VPSManager()
    this.setupEventHandlers()
    this.registerCommands()
  }

  setupEventHandlers() {
    this.client.once("ready", () => {
      console.log(`✅ Bot is ready! Logged in as ${this.client.user.tag}`)
      this.client.user.setActivity("Managing VPS instances", { type: ActivityType.Watching })
    })

    this.client.on("interactionCreate", async (interaction) => {
      try {
        // Added error handling for interactions
        if (interaction.isChatInputCommand()) {
          await this.handleSlashCommand(interaction)
        } else if (interaction.isButton()) {
          await this.handleButtonInteraction(interaction)
        }
      } catch (error) {
        console.error("Error handling interaction:", error.message)
        if (!interaction.replied && !interaction.deferred) {
          try {
            await interaction.reply({ content: "❌ An error occurred while processing your request.", ephemeral: true })
          } catch (replyError) {
            console.error("Error sending error reply:", replyError.message)
          }
        }
      }
    })
  }

  async registerCommands() {
    const commands = [
      new SlashCommandBuilder()
        .setName("deploy")
        .setDescription("Deploy a VPS for a user (Admin only)")
        .addUserOption((option) => option.setName("user").setDescription("User to deploy VPS for").setRequired(true))
        .addIntegerOption((option) =>
          option
            .setName("ram")
            .setDescription("RAM in MB (max 8192)")
            .setRequired(true)
            .setMinValue(512)
            .setMaxValue(CONFIG.MAX_RAM),
        )
        .addIntegerOption((option) =>
          option
            .setName("cpu")
            .setDescription("CPU cores (max 4)")
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(CONFIG.MAX_CPU),
        )
        .addIntegerOption((option) =>
          option
            .setName("storage")
            .setDescription("Storage in GB (max 50)")
            .setRequired(true)
            .setMinValue(5)
            .setMaxValue(CONFIG.MAX_STORAGE),
        )
        .addStringOption((option) =>
          option
            .setName("os")
            .setDescription("Operating System")
            .setRequired(true)
            .addChoices(
              ...Object.keys(CONFIG.SUPPORTED_OS).map((os) => ({
                name: os.charAt(0).toUpperCase() + os.slice(1),
                value: os,
              })),
            ),
        )
        .addStringOption((option) =>
          option.setName("password").setDescription("Custom password (optional)").setRequired(false),
        ),

      new SlashCommandBuilder().setName("list").setDescription("List all active VPS instances (Admin only)"),

      new SlashCommandBuilder()
        .setName("delete")
        .setDescription("Delete a VPS by VM ID (Admin only)")
        .addStringOption((option) => option.setName("vm_id").setDescription("VM ID to delete").setRequired(true)),

      new SlashCommandBuilder()
        .setName("manage")
        .setDescription("Manage your VPS")
        .addStringOption((option) => option.setName("vm_id").setDescription("Your VM ID").setRequired(true)),

      new SlashCommandBuilder().setName("myvps").setDescription("List your VPS instances"),
    ]

    this.client.once("ready", async () => {
      try {
        console.log("🔄 Registering slash commands...")
        await this.client.application.commands.set(commands)
        console.log("✅ Slash commands registered successfully!")
      } catch (error) {
        console.error("❌ Error registering commands:", error.message)
      }
    })
  }

  isAdmin(userId) {
    return CONFIG.ADMIN_IDS.includes(userId)
  }

  async handleSlashCommand(interaction) {
    const { commandName, user } = interaction

    try {
      switch (commandName) {
        case "deploy":
          await this.handleDeploy(interaction)
          break
        case "list":
          await this.handleList(interaction)
          break
        case "delete":
          await this.handleDelete(interaction)
          break
        case "manage":
          await this.handleManage(interaction)
          break
        case "myvps":
          await this.handleMyVPS(interaction)
          break
        default:
          await interaction.reply({ content: "❌ Unknown command!", ephemeral: true })
      }
    } catch (error) {
      console.error(`Error handling command ${commandName}:`, error.message)
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "❌ An error occurred while processing your command.",
          ephemeral: true,
        })
      } else if (interaction.deferred) {
        await interaction.editReply({
          content: "❌ An error occurred while processing your command.",
        })
      }
    }
  }

  async handleDeploy(interaction) {
    if (!this.isAdmin(interaction.user.id)) {
      return await interaction.reply({
        content: "❌ You do not have permission to use this command.",
        ephemeral: true,
      })
    }

    await interaction.deferReply()

    const targetUser = interaction.options.getUser("user")
    const ram = interaction.options.getInteger("ram")
    const cpu = interaction.options.getInteger("cpu")
    const storage = interaction.options.getInteger("storage")
    const os = interaction.options.getString("os")
    const password = interaction.options.getString("password")

    try {
      const vps = await this.vpsManager.createVPS({
        owner: targetUser.id,
        ram,
        cpu,
        storage,
        os,
        password,
      })

      // Send DM to target user
      const dmEmbed = new EmbedBuilder()
        .setTitle("🖥️ VPS Deployed Successfully!")
        .setColor(0x00ff00)
        .addFields(
          { name: "🆔 VM ID", value: vps.id, inline: true },
          { name: "💾 RAM", value: `${vps.specs.ram} MB`, inline: true },
          { name: "⚡ CPU", value: `${vps.specs.cpu} cores`, inline: true },
          { name: "💿 Storage", value: `${vps.specs.storage} GB`, inline: true },
          { name: "🖥️ OS", value: vps.specs.os.toUpperCase(), inline: true },
          { name: "🔐 Password", value: `\`${vps.password}\``, inline: true },
          { name: "🔗 SSH Connection", value: `\`${vps.ssh.command}\``, inline: false },
        )
        .setFooter({ text: "Use /manage to control your VPS" })
        .setTimestamp()

      try {
        await targetUser.send({ embeds: [dmEmbed] })
      } catch (dmError) {
        console.error("Could not send DM to user:", dmError)
      }

      // Reply to admin
      const adminEmbed = new EmbedBuilder()
        .setTitle("✅ VPS Deployed Successfully")
        .setColor(0x00ff00)
        .addFields(
          { name: "VM ID", value: vps.id, inline: true },
          { name: "Owner", value: `<@${targetUser.id}>`, inline: true },
          { name: "Specs", value: `${ram}MB RAM, ${cpu} CPU, ${storage}GB, ${os.toUpperCase()}`, inline: false },
        )
        .setTimestamp()

      await interaction.editReply({ embeds: [adminEmbed] })
    } catch (error) {
      console.error("Deployment error:", error)
      await interaction.editReply({
        content: `❌ Failed to deploy VPS: ${error.message}`,
      })
    }
  }

  async handleList(interaction) {
    if (!this.isAdmin(interaction.user.id)) {
      return await interaction.reply({
        content: "❌ You do not have permission to use this command.",
        ephemeral: true,
      })
    }

    const allVPS = this.vpsManager.getAllVPS()

    if (allVPS.length === 0) {
      return await interaction.reply({
        content: "📋 No active VPS instances found.",
        ephemeral: true,
      })
    }

    const embed = new EmbedBuilder().setTitle("📋 Active VPS Instances").setColor(0x0099ff).setTimestamp()

    allVPS.forEach((vps) => {
      embed.addFields({
        name: `🖥️ ${vps.id}`,
        value: `**Owner:** <@${vps.owner}>\n**Specs:** ${vps.specs.ram}MB RAM, ${vps.specs.cpu} CPU, ${vps.specs.storage}GB\n**OS:** ${vps.specs.os.toUpperCase()}\n**Status:** ${vps.status}`,
        inline: true,
      })
    })

    await interaction.reply({ embeds: [embed], ephemeral: true })
  }

  async handleDelete(interaction) {
    if (!this.isAdmin(interaction.user.id)) {
      return await interaction.reply({
        content: "❌ You do not have permission to use this command.",
        ephemeral: true,
      })
    }

    const vmId = interaction.options.getString("vm_id")
    const vps = this.vpsManager.getVPS(vmId)

    if (!vps) {
      return await interaction.reply({
        content: `❌ VPS with ID \`${vmId}\` not found.`,
        ephemeral: true,
      })
    }

    await interaction.deferReply()

    const success = await this.vpsManager.deleteVPS(vmId)

    if (success) {
      await interaction.editReply({
        content: `✅ VPS \`${vmId}\` has been deleted successfully.`,
      })
    } else {
      await interaction.editReply({
        content: `❌ Failed to delete VPS \`${vmId}\`.`,
      })
    }
  }

  async handleManage(interaction) {
    const vmId = interaction.options.getString("vm_id")
    const vps = this.vpsManager.getVPS(vmId)

    if (!vps) {
      return await interaction.reply({
        content: `❌ VPS with ID \`${vmId}\` not found.`,
        ephemeral: true,
      })
    }

    if (vps.owner !== interaction.user.id && !this.isAdmin(interaction.user.id)) {
      return await interaction.reply({
        content: "❌ You can only manage your own VPS instances.",
        ephemeral: true,
      })
    }

    const embed = new EmbedBuilder()
      .setTitle(`🖥️ Managing VPS: ${vmId}`)
      .setColor(0x0099ff)
      .addFields(
        { name: "💾 RAM", value: `${vps.specs.ram} MB`, inline: true },
        { name: "⚡ CPU", value: `${vps.specs.cpu} cores`, inline: true },
        { name: "💿 Storage", value: `${vps.specs.storage} GB`, inline: true },
        { name: "🖥️ OS", value: vps.specs.os.toUpperCase(), inline: true },
        { name: "📊 Status", value: vps.status, inline: true },
        { name: "🔗 SSH", value: `\`${vps.ssh.command}\``, inline: false },
      )
      .setTimestamp()

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`restart_${vmId}`).setLabel("🔄 Restart").setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`stop_${vmId}`).setLabel("⏹️ Stop").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`specs_${vmId}`).setLabel("📊 View Specs").setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`delete_${vmId}`).setLabel("🗑️ Delete").setStyle(ButtonStyle.Danger),
    )

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true })
  }

  async handleMyVPS(interaction) {
    const userVPS = this.vpsManager.getVPSByOwner(interaction.user.id)

    if (userVPS.length === 0) {
      return await interaction.reply({
        content: "📋 You don't have any VPS instances.",
        ephemeral: true,
      })
    }

    const embed = new EmbedBuilder().setTitle("🖥️ Your VPS Instances").setColor(0x0099ff).setTimestamp()

    userVPS.forEach((vps) => {
      embed.addFields({
        name: `🆔 ${vps.id}`,
        value: `**Specs:** ${vps.specs.ram}MB RAM, ${vps.specs.cpu} CPU, ${vps.specs.storage}GB\n**OS:** ${vps.specs.os.toUpperCase()}\n**Status:** ${vps.status}\n**Created:** ${new Date(vps.createdAt).toLocaleDateString()}`,
        inline: true,
      })
    })

    await interaction.reply({ embeds: [embed], ephemeral: true })
  }

  async handleButtonInteraction(interaction) {
    const [action, vmId] = interaction.customId.split("_")
    const vps = this.vpsManager.getVPS(vmId)

    if (!vps) {
      return await interaction.reply({
        content: "❌ VPS not found.",
        ephemeral: true,
      })
    }

    if (vps.owner !== interaction.user.id && !this.isAdmin(interaction.user.id)) {
      return await interaction.reply({
        content: "❌ You can only manage your own VPS instances.",
        ephemeral: true,
      })
    }

    await interaction.deferReply({ ephemeral: true })

    switch (action) {
      case "restart":
        const restartSuccess = await this.vpsManager.restartVPS(vmId)
        await interaction.editReply({
          content: restartSuccess
            ? `✅ VPS \`${vmId}\` restarted successfully.`
            : `❌ Failed to restart VPS \`${vmId}\`.`,
        })
        break

      case "stop":
        const stopSuccess = await this.vpsManager.stopVPS(vmId)
        await interaction.editReply({
          content: stopSuccess ? `✅ VPS \`${vmId}\` stopped successfully.` : `❌ Failed to stop VPS \`${vmId}\`.`,
        })
        break

      case "specs":
        const specsEmbed = new EmbedBuilder()
          .setTitle(`📊 VPS Specifications: ${vmId}`)
          .setColor(0x0099ff)
          .addFields(
            { name: "💾 RAM", value: `${vps.specs.ram} MB`, inline: true },
            { name: "⚡ CPU", value: `${vps.specs.cpu} cores`, inline: true },
            { name: "💿 Storage", value: `${vps.specs.storage} GB`, inline: true },
            { name: "🖥️ Operating System", value: vps.specs.os.toUpperCase(), inline: true },
            { name: "📊 Status", value: vps.status, inline: true },
            { name: "📅 Created", value: new Date(vps.createdAt).toLocaleString(), inline: true },
            { name: "🔐 Root Password", value: `\`${vps.password}\``, inline: false },
            { name: "🔗 SSH Connection", value: `\`${vps.ssh.command}\``, inline: false },
          )
          .setTimestamp()

        await interaction.editReply({ embeds: [specsEmbed] })
        break

      case "delete":
        const deleteSuccess = await this.vpsManager.deleteVPS(vmId)
        await interaction.editReply({
          content: deleteSuccess ? `✅ VPS \`${vmId}\` deleted successfully.` : `❌ Failed to delete VPS \`${vmId}\`.`,
        })
        break

      default:
        await interaction.editReply({ content: "❌ Unknown action." })
    }
  }

  async start() {
    if (!CONFIG.BOT_TOKEN || CONFIG.BOT_TOKEN === "YOUR_BOT_TOKEN_HERE") {
      console.error("❌ Bot token is required! Set DISCORD_BOT_TOKEN environment variable.")
      process.exit(1)
    }

    if (CONFIG.ADMIN_IDS.length === 0) {
      console.warn("⚠️  No admin IDs configured! Set ADMIN_IDS environment variable.")
    }

    try {
      await this.client.login(CONFIG.BOT_TOKEN)
    } catch (error) {
      console.error("❌ Failed to start bot:", error.message)
      process.exit(1)
    }
  }

  async shutdown() {
    console.log("🔄 Shutting down bot gracefully...")
    await this.vpsManager.cleanup()
    this.client.destroy()
  }
}

let bot
async function gracefulShutdown(signal) {
  console.log(`\n🔄 Received ${signal}, shutting down gracefully...`)
  if (bot) {
    await bot.shutdown()
  }
  process.exit(0)
}

process.on("SIGINT", () => gracefulShutdown("SIGINT"))
process.on("SIGTERM", () => gracefulShutdown("SIGTERM"))

process.on("uncaughtException", (error) => {
  console.error("Uncaught Exception:", error.message)
  console.error(error.stack)
  process.exit(1)
})

process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason)
})

// Start the bot
bot = new DiscordVPSBot()
bot.start()

console.log("🚀 Discord VPS Maker Bot starting...")
console.log("📋 Make sure to:")
console.log("   1. Set your DISCORD_BOT_TOKEN environment variable")
console.log("   2. Set ADMIN_IDS environment variable (comma-separated Discord user IDs)")
console.log("   3. Install required dependencies: npm install discord.js")
console.log("   4. Ensure Docker and tmate are installed on your system")
